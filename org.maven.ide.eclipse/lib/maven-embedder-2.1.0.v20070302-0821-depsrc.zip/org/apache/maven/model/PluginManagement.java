/*
 * $Id$
 */

package org.apache.maven.model;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.util.Date;

/**
 * 
 *         Section for management of default plugin information for
 * use in a group of POMs.
 *       
 * 
 * @version $Revision$ $Date$
 */
public class PluginManagement extends PluginContainer 
implements java.io.Serializable
{


    private String modelEncoding = "UTF-8";

    public void setModelEncoding( String modelEncoding )
    {
        this.modelEncoding = modelEncoding;
    }

    public String getModelEncoding()
    {
        return modelEncoding;
    }}
