/*
 * $Id$
 */

package org.apache.maven.model;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.util.Date;

/**
 * null
 * 
 * @version $Revision$ $Date$
 */
public class PluginConfiguration extends PluginContainer 
implements java.io.Serializable
{


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field pluginManagement
     */
    private PluginManagement pluginManagement;


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Get 
     *             Default plugin information to be made available
     * for reference by 
     *             projects derived from this one. This plugin
     * configuration will not
     *             be resolved or bound to the lifecycle unless
     * referenced. Any local
     *             configuration for a given plugin will override
     * the plugin's entire
     *             definition here.
     *           
     */
    public PluginManagement getPluginManagement()
    {
        return this.pluginManagement;
    } //-- PluginManagement getPluginManagement() 

    /**
     * Set 
     *             Default plugin information to be made available
     * for reference by 
     *             projects derived from this one. This plugin
     * configuration will not
     *             be resolved or bound to the lifecycle unless
     * referenced. Any local
     *             configuration for a given plugin will override
     * the plugin's entire
     *             definition here.
     *           
     * 
     * @param pluginManagement
     */
    public void setPluginManagement(PluginManagement pluginManagement)
    {
        this.pluginManagement = pluginManagement;
    } //-- void setPluginManagement(PluginManagement) 


    private String modelEncoding = "UTF-8";

    public void setModelEncoding( String modelEncoding )
    {
        this.modelEncoding = modelEncoding;
    }

    public String getModelEncoding()
    {
        return modelEncoding;
    }}
