/*
 * $Id$
 */

package org.apache.maven.model;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.util.Date;

/**
 * Describes the prerequisites a project can have.
 * 
 * @version $Revision$ $Date$
 */
public class Prerequisites implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field maven
     */
    private String maven = "2.0";


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Get The minimum version of Maven required to build the
     * project, or to use this plugin.
     */
    public String getMaven()
    {
        return this.maven;
    } //-- String getMaven() 

    /**
     * Set The minimum version of Maven required to build the
     * project, or to use this plugin.
     * 
     * @param maven
     */
    public void setMaven(String maven)
    {
        this.maven = maven;
    } //-- void setMaven(String) 


    private String modelEncoding = "UTF-8";

    public void setModelEncoding( String modelEncoding )
    {
        this.modelEncoding = modelEncoding;
    }

    public String getModelEncoding()
    {
        return modelEncoding;
    }}
