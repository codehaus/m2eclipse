/*
 * $Id$
 */

package org.apache.maven.plugin.lifecycle.io.xpp3;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.Writer;
import java.text.DateFormat;
import java.util.Iterator;
import java.util.Locale;
import org.apache.maven.plugin.lifecycle.Execution;
import org.apache.maven.plugin.lifecycle.Lifecycle;
import org.apache.maven.plugin.lifecycle.LifecycleConfiguration;
import org.apache.maven.plugin.lifecycle.Phase;
import org.codehaus.plexus.util.xml.Xpp3Dom;
import org.codehaus.plexus.util.xml.pull.MXSerializer;
import org.codehaus.plexus.util.xml.pull.XmlSerializer;

/**
 * Class LifecycleMappingsXpp3Writer.
 * 
 * @version $Revision$ $Date$
 */
public class LifecycleMappingsXpp3Writer {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field NAMESPACE
     */
    private String NAMESPACE;


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method write
     * 
     * @param writer
     * @param lifecycleConfiguration
     */
    public void write(Writer writer, LifecycleConfiguration lifecycleConfiguration)
        throws java.io.IOException
    {
        XmlSerializer serializer = new MXSerializer();
        serializer.setProperty( "http://xmlpull.org/v1/doc/properties.html#serializer-indentation", "  " );
        serializer.setProperty( "http://xmlpull.org/v1/doc/properties.html#serializer-line-separator", "\n" );
        serializer.setOutput( writer );
        serializer.startDocument( lifecycleConfiguration.getModelEncoding(), null );
        writeLifecycleConfiguration( lifecycleConfiguration, "lifecycles", serializer );
        serializer.endDocument();
    } //-- void write(Writer, LifecycleConfiguration) 

    /**
     * Method writeExecution
     * 
     * @param execution
     * @param serializer
     * @param tagName
     */
    private void writeExecution(Execution execution, String tagName, XmlSerializer serializer)
        throws java.io.IOException
    {
        if ( execution != null )
        {
            serializer.startTag( NAMESPACE, tagName );
            if ( execution.getConfiguration() != null )
            {
                ((Xpp3Dom) execution.getConfiguration()).writeToSerializer( NAMESPACE, serializer );
            }
            if ( execution.getGoals() != null && execution.getGoals().size() > 0 )
            {
                serializer.startTag( NAMESPACE, "goals" );
                for ( Iterator iter = execution.getGoals().iterator(); iter.hasNext(); )
                {
                    String goal = (String) iter.next();
                    serializer.startTag( NAMESPACE, "goal" ).text( goal ).endTag( NAMESPACE, "goal" );
                }
                serializer.endTag( NAMESPACE, "goals" );
            }
            serializer.endTag( NAMESPACE, tagName );
        }
    } //-- void writeExecution(Execution, String, XmlSerializer) 

    /**
     * Method writeLifecycle
     * 
     * @param lifecycle
     * @param serializer
     * @param tagName
     */
    private void writeLifecycle(Lifecycle lifecycle, String tagName, XmlSerializer serializer)
        throws java.io.IOException
    {
        if ( lifecycle != null )
        {
            serializer.startTag( NAMESPACE, tagName );
            if ( lifecycle.getId() != null )
            {
                serializer.startTag( NAMESPACE, "id" ).text( lifecycle.getId() ).endTag( NAMESPACE, "id" );
            }
            if ( lifecycle.getPhases() != null && lifecycle.getPhases().size() > 0 )
            {
                serializer.startTag( NAMESPACE, "phases" );
                for ( Iterator iter = lifecycle.getPhases().iterator(); iter.hasNext(); )
                {
                    Phase o = (Phase) iter.next();
                    writePhase( o, "phase", serializer );
                }
                serializer.endTag( NAMESPACE, "phases" );
            }
            serializer.endTag( NAMESPACE, tagName );
        }
    } //-- void writeLifecycle(Lifecycle, String, XmlSerializer) 

    /**
     * Method writeLifecycleConfiguration
     * 
     * @param lifecycleConfiguration
     * @param serializer
     * @param tagName
     */
    private void writeLifecycleConfiguration(LifecycleConfiguration lifecycleConfiguration, String tagName, XmlSerializer serializer)
        throws java.io.IOException
    {
        if ( lifecycleConfiguration != null )
        {
            serializer.startTag( NAMESPACE, tagName );
            if ( lifecycleConfiguration.getLifecycles() != null && lifecycleConfiguration.getLifecycles().size() > 0 )
            {
                for ( Iterator iter = lifecycleConfiguration.getLifecycles().iterator(); iter.hasNext(); )
                {
                    Lifecycle o = (Lifecycle) iter.next();
                    writeLifecycle( o, "lifecycle", serializer );
                }
            }
            serializer.endTag( NAMESPACE, tagName );
        }
    } //-- void writeLifecycleConfiguration(LifecycleConfiguration, String, XmlSerializer) 

    /**
     * Method writePhase
     * 
     * @param phase
     * @param serializer
     * @param tagName
     */
    private void writePhase(Phase phase, String tagName, XmlSerializer serializer)
        throws java.io.IOException
    {
        if ( phase != null )
        {
            serializer.startTag( NAMESPACE, tagName );
            if ( phase.getId() != null )
            {
                serializer.startTag( NAMESPACE, "id" ).text( phase.getId() ).endTag( NAMESPACE, "id" );
            }
            if ( phase.getExecutions() != null && phase.getExecutions().size() > 0 )
            {
                serializer.startTag( NAMESPACE, "executions" );
                for ( Iterator iter = phase.getExecutions().iterator(); iter.hasNext(); )
                {
                    Execution o = (Execution) iter.next();
                    writeExecution( o, "execution", serializer );
                }
                serializer.endTag( NAMESPACE, "executions" );
            }
            if ( phase.getConfiguration() != null )
            {
                ((Xpp3Dom) phase.getConfiguration()).writeToSerializer( NAMESPACE, serializer );
            }
            serializer.endTag( NAMESPACE, tagName );
        }
    } //-- void writePhase(Phase, String, XmlSerializer) 


}
