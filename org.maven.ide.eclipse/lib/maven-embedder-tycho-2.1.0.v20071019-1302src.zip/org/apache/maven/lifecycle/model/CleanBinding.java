/*
 * $Id$
 */

package org.apache.maven.lifecycle.model;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.util.Date;

/**
 * null
 * 
 * @version $Revision$ $Date$
 */
public class CleanBinding extends LifecycleBinding 
implements java.io.Serializable
{


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field preClean
     */
    private Phase preClean = new Phase();

    /**
     * Field clean
     */
    private Phase clean = new Phase();

    /**
     * Field postClean
     */
    private Phase postClean = new Phase();


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Get null
     */
    public Phase getClean()
    {
        return this.clean;
    } //-- Phase getClean() 

    /**
     * Get null
     */
    public Phase getPostClean()
    {
        return this.postClean;
    } //-- Phase getPostClean() 

    /**
     * Get null
     */
    public Phase getPreClean()
    {
        return this.preClean;
    } //-- Phase getPreClean() 

    /**
     * Set null
     * 
     * @param clean
     */
    public void setClean(Phase clean)
    {
        this.clean = clean;
    } //-- void setClean(Phase) 

    /**
     * Set null
     * 
     * @param postClean
     */
    public void setPostClean(Phase postClean)
    {
        this.postClean = postClean;
    } //-- void setPostClean(Phase) 

    /**
     * Set null
     * 
     * @param preClean
     */
    public void setPreClean(Phase preClean)
    {
        this.preClean = preClean;
    } //-- void setPreClean(Phase) 


    public String getId()
    {
        return "clean";
    }
          
    public java.util.List getPhasesInOrder()
    {
        java.util.List phases = new java.util.ArrayList();
        
        phases.add( getPreClean() );
        phases.add( getClean() );
        phases.add( getPostClean() );
        
        return java.util.Collections.unmodifiableList( phases );
    }
    
    public java.util.List getPhaseNamesInOrder()
    {
        java.util.List phases = new java.util.ArrayList();
        
        phases.add( "pre-clean" );
        phases.add( "clean" );
        phases.add( "post-clean" );
        
        return java.util.Collections.unmodifiableList( phases );
    }
          
    private String modelEncoding = "UTF-8";

    public void setModelEncoding( String modelEncoding )
    {
        this.modelEncoding = modelEncoding;
    }

    public String getModelEncoding()
    {
        return modelEncoding;
    }
}
