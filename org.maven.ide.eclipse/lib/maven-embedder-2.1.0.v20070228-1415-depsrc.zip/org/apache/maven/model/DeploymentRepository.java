/*
 * $Id$
 */

package org.apache.maven.model;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.util.Date;

/**
 * 
 *         Repository contains the information needed for deploying
 * to the remote repository.
 *       
 * 
 * @version $Revision$ $Date$
 */
public class DeploymentRepository extends RepositoryBase 
implements java.io.Serializable
{


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field uniqueVersion
     */
    private boolean uniqueVersion = true;


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Get Whether to assign snapshots a unique version comprised
     * of the timestamp and build number, or to
     *             use the same version each time
     */
    public boolean isUniqueVersion()
    {
        return this.uniqueVersion;
    } //-- boolean isUniqueVersion() 

    /**
     * Set Whether to assign snapshots a unique version comprised
     * of the timestamp and build number, or to
     *             use the same version each time
     * 
     * @param uniqueVersion
     */
    public void setUniqueVersion(boolean uniqueVersion)
    {
        this.uniqueVersion = uniqueVersion;
    } //-- void setUniqueVersion(boolean) 


            public boolean equals( Object obj )
            {
                return super.equals( obj );
            }
          
    private String modelEncoding = "UTF-8";

    public void setModelEncoding( String modelEncoding )
    {
        this.modelEncoding = modelEncoding;
    }

    public String getModelEncoding()
    {
        return modelEncoding;
    }}
