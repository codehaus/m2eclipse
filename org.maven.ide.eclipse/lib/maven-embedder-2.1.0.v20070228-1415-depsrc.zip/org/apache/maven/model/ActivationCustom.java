/*
 * $Id$
 */

package org.apache.maven.model;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.util.Date;

/**
 * 
 *         This activation allows users to specify their own custom
 * trigger for a profile.
 *       
 * 
 * @version $Revision$ $Date$
 */
public class ActivationCustom implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field configuration
     */
    private Object configuration;

    /**
     * Field type
     */
    private String type;


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Get 
     *             The specification for triggering the profile
     * according to the rules of the custom
     *             activation type.
     *           
     */
    public Object getConfiguration()
    {
        return this.configuration;
    } //-- Object getConfiguration() 

    /**
     * Get 
     *             The type (role-hint) of activation which is to
     * be used to activate the profile.
     *           
     */
    public String getType()
    {
        return this.type;
    } //-- String getType() 

    /**
     * Set 
     *             The specification for triggering the profile
     * according to the rules of the custom
     *             activation type.
     *           
     * 
     * @param configuration
     */
    public void setConfiguration(Object configuration)
    {
        this.configuration = configuration;
    } //-- void setConfiguration(Object) 

    /**
     * Set 
     *             The type (role-hint) of activation which is to
     * be used to activate the profile.
     *           
     * 
     * @param type
     */
    public void setType(String type)
    {
        this.type = type;
    } //-- void setType(String) 


    private String modelEncoding = "UTF-8";

    public void setModelEncoding( String modelEncoding )
    {
        this.modelEncoding = modelEncoding;
    }

    public String getModelEncoding()
    {
        return modelEncoding;
    }}
