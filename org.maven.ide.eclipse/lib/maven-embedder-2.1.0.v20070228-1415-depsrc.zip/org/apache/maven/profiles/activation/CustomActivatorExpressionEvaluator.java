package org.apache.maven.profiles.activation;

import org.codehaus.plexus.component.configurator.expression.ExpressionEvaluationException;
import org.codehaus.plexus.component.configurator.expression.ExpressionEvaluator;

import java.io.File;

public class CustomActivatorExpressionEvaluator
    implements ExpressionEvaluator
{

    public File alignToBaseDirectory( File file )
    {
        // TODO Auto-generated method stub
        return null;
    }

    public Object evaluate( String expression )
        throws ExpressionEvaluationException
    {
        // TODO Auto-generated method stub
        return null;
    }

}
