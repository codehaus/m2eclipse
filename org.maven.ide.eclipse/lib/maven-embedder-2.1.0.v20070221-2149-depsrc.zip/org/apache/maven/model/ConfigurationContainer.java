/*
 * $Id$
 */

package org.apache.maven.model;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.util.Date;

/**
 * null
 * 
 * @version $Revision$ $Date$
 */
public class ConfigurationContainer implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field inherited
     */
    private String inherited;

    /**
     * Field configuration
     */
    private Object configuration;


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Get null
     */
    public Object getConfiguration()
    {
        return this.configuration;
    } //-- Object getConfiguration() 

    /**
     * Get 
     *             Whether any configuration should be propagated
     * to child POMs.
     */
    public String getInherited()
    {
        return this.inherited;
    } //-- String getInherited() 

    /**
     * Set null
     * 
     * @param configuration
     */
    public void setConfiguration(Object configuration)
    {
        this.configuration = configuration;
    } //-- void setConfiguration(Object) 

    /**
     * Set 
     *             Whether any configuration should be propagated
     * to child POMs.
     * 
     * @param inherited
     */
    public void setInherited(String inherited)
    {
        this.inherited = inherited;
    } //-- void setInherited(String) 


    private boolean inheritanceApplied = true;
    
    public void unsetInheritanceApplied()
    {
        this.inheritanceApplied = false;
    }
    
    public boolean isInheritanceApplied()
    {
        return inheritanceApplied;
    }
          
    private String modelEncoding = "UTF-8";

    public void setModelEncoding( String modelEncoding )
    {
        this.modelEncoding = modelEncoding;
    }

    public String getModelEncoding()
    {
        return modelEncoding;
    }}
