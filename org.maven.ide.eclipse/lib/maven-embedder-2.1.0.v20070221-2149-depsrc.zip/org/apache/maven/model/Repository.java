/*
 * $Id$
 */

package org.apache.maven.model;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.util.Date;

/**
 * 
 *         A repository contains the information needed for
 * establishing connections with remote repository.
 *       
 * 
 * @version $Revision$ $Date$
 */
public class Repository extends RepositoryBase 
implements java.io.Serializable
{


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field releases
     */
    private RepositoryPolicy releases;

    /**
     * Field snapshots
     */
    private RepositoryPolicy snapshots;


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Get How to handle downloading of releases from this
     * repository.
     */
    public RepositoryPolicy getReleases()
    {
        return this.releases;
    } //-- RepositoryPolicy getReleases() 

    /**
     * Get How to handle downloading of snapshots from this
     * repository.
     */
    public RepositoryPolicy getSnapshots()
    {
        return this.snapshots;
    } //-- RepositoryPolicy getSnapshots() 

    /**
     * Set How to handle downloading of releases from this
     * repository.
     * 
     * @param releases
     */
    public void setReleases(RepositoryPolicy releases)
    {
        this.releases = releases;
    } //-- void setReleases(RepositoryPolicy) 

    /**
     * Set How to handle downloading of snapshots from this
     * repository.
     * 
     * @param snapshots
     */
    public void setSnapshots(RepositoryPolicy snapshots)
    {
        this.snapshots = snapshots;
    } //-- void setSnapshots(RepositoryPolicy) 


            public boolean equals( Object obj )
            {
                return super.equals( obj );
            }
          
    private String modelEncoding = "UTF-8";

    public void setModelEncoding( String modelEncoding )
    {
        this.modelEncoding = modelEncoding;
    }

    public String getModelEncoding()
    {
        return modelEncoding;
    }}
