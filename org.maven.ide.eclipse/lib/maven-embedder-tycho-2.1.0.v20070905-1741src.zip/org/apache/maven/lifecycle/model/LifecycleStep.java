/*
 * $Id$
 */

package org.apache.maven.lifecycle.model;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.util.Date;

/**
 * 
 *         Some step in the build process. This could be a mojo, or
 * it could be a signal to start/stop 
 *         forked-mode of execution, etc.
 *       
 * 
 * @version $Revision$ $Date$
 */
public class LifecycleStep implements java.io.Serializable {


    private String modelEncoding = "UTF-8";

    public void setModelEncoding( String modelEncoding )
    {
        this.modelEncoding = modelEncoding;
    }

    public String getModelEncoding()
    {
        return modelEncoding;
    }
}
