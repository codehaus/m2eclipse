/*
 * $Id$
 */

package org.apache.maven.lifecycle.model;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.util.Date;

/**
 * Base-class for all lifecycle bindings.
 * 
 * @version $Revision$ $Date$
 */
public class LifecycleBinding implements java.io.Serializable {


    public String getId()
    {
        throw new UnsupportedOperationException( "Unsupported in base-class." );
    }
          
    public java.util.List getPhasesInOrder()
    {
        throw new UnsupportedOperationException( "Unsupported in base-class." );
    }
    
    public java.util.List getPhaseNamesInOrder()
    {
        throw new UnsupportedOperationException( "Unsupported in base-class." );
    }
          
    private String modelEncoding = "UTF-8";

    public void setModelEncoding( String modelEncoding )
    {
        this.modelEncoding = modelEncoding;
    }

    public String getModelEncoding()
    {
        return modelEncoding;
    }
}
