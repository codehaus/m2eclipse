/*
 * $Id$
 */

package org.apache.maven.lifecycle.model;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.util.Date;

/**
 * Specifies phase bindings for clean, site, and default
 * lifecycles.
 * 
 * @version $Revision$ $Date$
 */
public class LifecycleBindings implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field packaging
     */
    private String packaging;

    /**
     * Field cleanBinding
     */
    private CleanBinding cleanBinding = new CleanBinding();

    /**
     * Field buildBinding
     */
    private BuildBinding buildBinding = new BuildBinding();

    /**
     * Field siteBinding
     */
    private SiteBinding siteBinding = new SiteBinding();


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Get The binding for the main build (default) lifecycle
     */
    public BuildBinding getBuildBinding()
    {
        return this.buildBinding;
    } //-- BuildBinding getBuildBinding() 

    /**
     * Get The binding for the clean lifecycle
     */
    public CleanBinding getCleanBinding()
    {
        return this.cleanBinding;
    } //-- CleanBinding getCleanBinding() 

    /**
     * Get POM packaging to which this lifecycle specification
     * applies.
     */
    public String getPackaging()
    {
        return this.packaging;
    } //-- String getPackaging() 

    /**
     * Get The binding for the site lifecycle
     */
    public SiteBinding getSiteBinding()
    {
        return this.siteBinding;
    } //-- SiteBinding getSiteBinding() 

    /**
     * Set The binding for the main build (default) lifecycle
     * 
     * @param buildBinding
     */
    public void setBuildBinding(BuildBinding buildBinding)
    {
        this.buildBinding = buildBinding;
    } //-- void setBuildBinding(BuildBinding) 

    /**
     * Set The binding for the clean lifecycle
     * 
     * @param cleanBinding
     */
    public void setCleanBinding(CleanBinding cleanBinding)
    {
        this.cleanBinding = cleanBinding;
    } //-- void setCleanBinding(CleanBinding) 

    /**
     * Set POM packaging to which this lifecycle specification
     * applies.
     * 
     * @param packaging
     */
    public void setPackaging(String packaging)
    {
        this.packaging = packaging;
    } //-- void setPackaging(String) 

    /**
     * Set The binding for the site lifecycle
     * 
     * @param siteBinding
     */
    public void setSiteBinding(SiteBinding siteBinding)
    {
        this.siteBinding = siteBinding;
    } //-- void setSiteBinding(SiteBinding) 


    public java.util.List getBindingList()
    {
        java.util.List lifecycles = new java.util.ArrayList();
        
        if ( getCleanBinding() != null )
        {
            lifecycles.add( getCleanBinding() );
        }
        
        if ( getBuildBinding() != null )
        {
            lifecycles.add( getBuildBinding() );
        }
        
        if ( getSiteBinding() != null )
        {
            lifecycles.add( getSiteBinding() );
        }
        
        return java.util.Collections.unmodifiableList( lifecycles );
    }
          
    private String modelEncoding = "UTF-8";

    public void setModelEncoding( String modelEncoding )
    {
        this.modelEncoding = modelEncoding;
    }

    public String getModelEncoding()
    {
        return modelEncoding;
    }
}
