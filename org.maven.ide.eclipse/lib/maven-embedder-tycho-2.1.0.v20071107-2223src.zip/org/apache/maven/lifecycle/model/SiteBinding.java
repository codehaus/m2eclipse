/*
 * $Id$
 */

package org.apache.maven.lifecycle.model;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.util.Date;

/**
 * null
 * 
 * @version $Revision$ $Date$
 */
public class SiteBinding extends LifecycleBinding 
implements java.io.Serializable
{


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field preSite
     */
    private Phase preSite = new Phase();

    /**
     * Field site
     */
    private Phase site = new Phase();

    /**
     * Field postSite
     */
    private Phase postSite = new Phase();

    /**
     * Field siteDeploy
     */
    private Phase siteDeploy = new Phase();


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Get null
     */
    public Phase getPostSite()
    {
        return this.postSite;
    } //-- Phase getPostSite() 

    /**
     * Get null
     */
    public Phase getPreSite()
    {
        return this.preSite;
    } //-- Phase getPreSite() 

    /**
     * Get null
     */
    public Phase getSite()
    {
        return this.site;
    } //-- Phase getSite() 

    /**
     * Get null
     */
    public Phase getSiteDeploy()
    {
        return this.siteDeploy;
    } //-- Phase getSiteDeploy() 

    /**
     * Set null
     * 
     * @param postSite
     */
    public void setPostSite(Phase postSite)
    {
        this.postSite = postSite;
    } //-- void setPostSite(Phase) 

    /**
     * Set null
     * 
     * @param preSite
     */
    public void setPreSite(Phase preSite)
    {
        this.preSite = preSite;
    } //-- void setPreSite(Phase) 

    /**
     * Set null
     * 
     * @param site
     */
    public void setSite(Phase site)
    {
        this.site = site;
    } //-- void setSite(Phase) 

    /**
     * Set null
     * 
     * @param siteDeploy
     */
    public void setSiteDeploy(Phase siteDeploy)
    {
        this.siteDeploy = siteDeploy;
    } //-- void setSiteDeploy(Phase) 


    public String getId()
    {
        return "site";
    }
          
    public java.util.List getPhasesInOrder()
    {
        java.util.List phases = new java.util.ArrayList();
        
        phases.add( getPreSite() );
        phases.add( getSite() );
        phases.add( getPostSite() );
        phases.add( getSiteDeploy() );
        
        return java.util.Collections.unmodifiableList( phases );
    }
    
    public java.util.List getPhaseNamesInOrder()
    {
        java.util.List phases = new java.util.ArrayList();
        
        phases.add( "pre-site" );
        phases.add( "site" );
        phases.add( "post-site" );
        phases.add( "site-deploy" );
        
        return java.util.Collections.unmodifiableList( phases );
    }
          
    private String modelEncoding = "UTF-8";

    public void setModelEncoding( String modelEncoding )
    {
        this.modelEncoding = modelEncoding;
    }

    public String getModelEncoding()
    {
        return modelEncoding;
    }
}
