/*
 * $Id$
 */

package org.apache.maven.lifecycle.model;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.util.Date;

/**
 * Contains a series of mojo bindings for a given phase of a
 * lifecycle.
 * 
 * @version $Revision$ $Date$
 */
public class Phase implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field bindings
     */
    private java.util.List bindings;


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addBinding
     * 
     * @param mojoBinding
     */
    public void addBinding(MojoBinding mojoBinding)
    {
        if ( !(mojoBinding instanceof MojoBinding) )
        {
            throw new ClassCastException( "Phase.addBindings(mojoBinding) parameter must be instanceof " + MojoBinding.class.getName() );
        }
        getBindings().add( mojoBinding );
    } //-- void addBinding(MojoBinding) 

    /**
     * Method getBindings
     */
    public java.util.List getBindings()
    {
        if ( this.bindings == null )
        {
            this.bindings = new java.util.ArrayList();
        }
        
        return this.bindings;
    } //-- java.util.List getBindings() 

    /**
     * Method removeBinding
     * 
     * @param mojoBinding
     */
    public void removeBinding(MojoBinding mojoBinding)
    {
        if ( !(mojoBinding instanceof MojoBinding) )
        {
            throw new ClassCastException( "Phase.removeBindings(mojoBinding) parameter must be instanceof " + MojoBinding.class.getName() );
        }
        getBindings().remove( mojoBinding );
    } //-- void removeBinding(MojoBinding) 

    /**
     * Set Collection of mojo bindings for a phase.
     * 
     * @param bindings
     */
    public void setBindings(java.util.List bindings)
    {
        this.bindings = bindings;
    } //-- void setBindings(java.util.List) 


    private String modelEncoding = "UTF-8";

    public void setModelEncoding( String modelEncoding )
    {
        this.modelEncoding = modelEncoding;
    }

    public String getModelEncoding()
    {
        return modelEncoding;
    }
}
