/*
 * $Id$
 */

package org.apache.maven.settings;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.util.Date;

/**
 * 
 *         
 *         This is the file specification used to activate a
 * profile. The missing value will be a the location
 *         of a file that needs to exist, and if it doesn't the
 * profile must run.  On the other hand exists will test
 *         for the existence of the file and if it is there will
 * run the profile.
 *         
 *       
 * 
 * @version $Revision$ $Date$
 */
public class ActivationFile implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field missing
     */
    private String missing;

    /**
     * Field exists
     */
    private String exists;


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Get 
     *             The name of the file that should exist to
     * activate a profile.
     *           
     */
    public String getExists()
    {
        return this.exists;
    } //-- String getExists() 

    /**
     * Get 
     *             The name of the file that should be missing to
     * activate a
     *             profile.
     *           
     */
    public String getMissing()
    {
        return this.missing;
    } //-- String getMissing() 

    /**
     * Set 
     *             The name of the file that should exist to
     * activate a profile.
     *           
     * 
     * @param exists
     */
    public void setExists(String exists)
    {
        this.exists = exists;
    } //-- void setExists(String) 

    /**
     * Set 
     *             The name of the file that should be missing to
     * activate a
     *             profile.
     *           
     * 
     * @param missing
     */
    public void setMissing(String missing)
    {
        this.missing = missing;
    } //-- void setMissing(String) 


    private String modelEncoding = "UTF-8";

    public void setModelEncoding( String modelEncoding )
    {
        this.modelEncoding = modelEncoding;
    }

    public String getModelEncoding()
    {
        return modelEncoding;
    }
}
