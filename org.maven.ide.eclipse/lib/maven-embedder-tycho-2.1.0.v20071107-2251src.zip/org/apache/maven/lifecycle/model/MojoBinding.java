/*
 * $Id$
 */

package org.apache.maven.lifecycle.model;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.util.Date;

/**
 * A binding of one mojo to one lifecycle phase, possibly including
 * configuration.
 * 
 * @version $Revision$ $Date$
 */
public class MojoBinding extends LifecycleStep 
implements java.io.Serializable
{


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field groupId
     */
    private String groupId;

    /**
     * Field artifactId
     */
    private String artifactId;

    /**
     * Field version
     */
    private String version;

    /**
     * Field goal
     */
    private String goal;

    /**
     * Field executionId
     */
    private String executionId = "default";

    /**
     * Field origin
     */
    private String origin;

    /**
     * Field configuration
     */
    private Object configuration;

    /**
     * Field optional
     */
    private boolean optional = false;


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method equals
     * 
     * @param other
     */
    public boolean equals(Object other)
    {
        if ( this == other)
        {
            return true;
        }
        
        if ( !(other instanceof MojoBinding) )
        {
            return false;
        }
        
        MojoBinding that = (MojoBinding) other;
        boolean result = true;
        result = result && ( getGroupId() == null ? that.getGroupId() == null : getGroupId().equals( that.getGroupId() ) );
        result = result && ( getArtifactId() == null ? that.getArtifactId() == null : getArtifactId().equals( that.getArtifactId() ) );
        result = result && ( getGoal() == null ? that.getGoal() == null : getGoal().equals( that.getGoal() ) );
        result = result && ( getExecutionId() == null ? that.getExecutionId() == null : getExecutionId().equals( that.getExecutionId() ) );
        return result;
    } //-- boolean equals(Object) 

    /**
     * Get Plugin's artifactId.
     */
    public String getArtifactId()
    {
        return this.artifactId;
    } //-- String getArtifactId() 

    /**
     * Get Mojo binding's configuration.
     */
    public Object getConfiguration()
    {
        return this.configuration;
    } //-- Object getConfiguration() 

    /**
     * Get A name for this mojo binding, for purposes of merging
     * configurations via inheritance, etc.
     */
    public String getExecutionId()
    {
        return this.executionId;
    } //-- String getExecutionId() 

    /**
     * Get Mojo's goal name.
     */
    public String getGoal()
    {
        return this.goal;
    } //-- String getGoal() 

    /**
     * Get Plugin's groupId.
     */
    public String getGroupId()
    {
        return this.groupId;
    } //-- String getGroupId() 

    /**
     * Get Specific location from which this set of mojo binding
     * was loaded.
     */
    public String getOrigin()
    {
        return this.origin;
    } //-- String getOrigin() 

    /**
     * Get Plugin's version.
     */
    public String getVersion()
    {
        return this.version;
    } //-- String getVersion() 

    /**
     * Method hashCode
     */
    public int hashCode()
    {
        int result = 17;
        long tmp;
        result = 37 * result + ( groupId != null ? groupId.hashCode() : 0 );
        result = 37 * result + ( artifactId != null ? artifactId.hashCode() : 0 );
        result = 37 * result + ( goal != null ? goal.hashCode() : 0 );
        result = 37 * result + ( executionId != null ? executionId.hashCode() : 0 );
        return result;
    } //-- int hashCode() 

    /**
     * Get Marks a mojo binding as optional (not required for
     * execution of the lifecycle).
     */
    public boolean isOptional()
    {
        return this.optional;
    } //-- boolean isOptional() 

    /**
     * Set Plugin's artifactId.
     * 
     * @param artifactId
     */
    public void setArtifactId(String artifactId)
    {
        this.artifactId = artifactId;
    } //-- void setArtifactId(String) 

    /**
     * Set Mojo binding's configuration.
     * 
     * @param configuration
     */
    public void setConfiguration(Object configuration)
    {
        this.configuration = configuration;
    } //-- void setConfiguration(Object) 

    /**
     * Set A name for this mojo binding, for purposes of merging
     * configurations via inheritance, etc.
     * 
     * @param executionId
     */
    public void setExecutionId(String executionId)
    {
        this.executionId = executionId;
    } //-- void setExecutionId(String) 

    /**
     * Set Mojo's goal name.
     * 
     * @param goal
     */
    public void setGoal(String goal)
    {
        this.goal = goal;
    } //-- void setGoal(String) 

    /**
     * Set Plugin's groupId.
     * 
     * @param groupId
     */
    public void setGroupId(String groupId)
    {
        this.groupId = groupId;
    } //-- void setGroupId(String) 

    /**
     * Set Marks a mojo binding as optional (not required for
     * execution of the lifecycle).
     * 
     * @param optional
     */
    public void setOptional(boolean optional)
    {
        this.optional = optional;
    } //-- void setOptional(boolean) 

    /**
     * Set Specific location from which this set of mojo binding
     * was loaded.
     * 
     * @param origin
     */
    public void setOrigin(String origin)
    {
        this.origin = origin;
    } //-- void setOrigin(String) 

    /**
     * Set Plugin's version.
     * 
     * @param version
     */
    public void setVersion(String version)
    {
        this.version = version;
    } //-- void setVersion(String) 

    /**
     * Method toString
     */
    public java.lang.String toString()
    {
        StringBuffer buf = new StringBuffer();
        buf.append( "groupId = '" );
        buf.append( getGroupId() + "'" );
        buf.append( "\n" ); 
        buf.append( "artifactId = '" );
        buf.append( getArtifactId() + "'" );
        buf.append( "\n" ); 
        buf.append( "goal = '" );
        buf.append( getGoal() + "'" );
        buf.append( "\n" ); 
        buf.append( "executionId = '" );
        buf.append( getExecutionId() + "'" );
        return buf.toString();
    } //-- java.lang.String toString() 


    private boolean lateBound = false;
          
    public boolean isLateBound()
    {
        return lateBound;
    }
          
    public void setLateBound( boolean lateBound )
    {
        this.lateBound = lateBound;
    }
          
    private String modelEncoding = "UTF-8";

    public void setModelEncoding( String modelEncoding )
    {
        this.modelEncoding = modelEncoding;
    }

    public String getModelEncoding()
    {
        return modelEncoding;
    }
}
