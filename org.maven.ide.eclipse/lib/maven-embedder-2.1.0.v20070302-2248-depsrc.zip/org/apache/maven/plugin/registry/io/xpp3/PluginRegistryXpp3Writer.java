/*
 * $Id$
 */

package org.apache.maven.plugin.registry.io.xpp3;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.Writer;
import java.text.DateFormat;
import java.util.Iterator;
import java.util.Locale;
import org.apache.maven.plugin.registry.Plugin;
import org.apache.maven.plugin.registry.PluginRegistry;
import org.apache.maven.plugin.registry.TrackableBase;
import org.codehaus.plexus.util.xml.pull.MXSerializer;
import org.codehaus.plexus.util.xml.pull.XmlSerializer;

/**
 * Class PluginRegistryXpp3Writer.
 * 
 * @version $Revision$ $Date$
 */
public class PluginRegistryXpp3Writer {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field NAMESPACE
     */
    private String NAMESPACE;


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method write
     * 
     * @param writer
     * @param pluginRegistry
     */
    public void write(Writer writer, PluginRegistry pluginRegistry)
        throws java.io.IOException
    {
        XmlSerializer serializer = new MXSerializer();
        serializer.setProperty( "http://xmlpull.org/v1/doc/properties.html#serializer-indentation", "  " );
        serializer.setProperty( "http://xmlpull.org/v1/doc/properties.html#serializer-line-separator", "\n" );
        serializer.setOutput( writer );
        serializer.startDocument( pluginRegistry.getModelEncoding(), null );
        writePluginRegistry( pluginRegistry, "pluginRegistry", serializer );
        serializer.endDocument();
    } //-- void write(Writer, PluginRegistry) 

    /**
     * Method writePlugin
     * 
     * @param plugin
     * @param serializer
     * @param tagName
     */
    private void writePlugin(Plugin plugin, String tagName, XmlSerializer serializer)
        throws java.io.IOException
    {
        if ( plugin != null )
        {
            serializer.startTag( NAMESPACE, tagName );
            if ( plugin.getGroupId() != null )
            {
                serializer.startTag( NAMESPACE, "groupId" ).text( plugin.getGroupId() ).endTag( NAMESPACE, "groupId" );
            }
            if ( plugin.getArtifactId() != null )
            {
                serializer.startTag( NAMESPACE, "artifactId" ).text( plugin.getArtifactId() ).endTag( NAMESPACE, "artifactId" );
            }
            if ( plugin.getLastChecked() != null )
            {
                serializer.startTag( NAMESPACE, "lastChecked" ).text( plugin.getLastChecked() ).endTag( NAMESPACE, "lastChecked" );
            }
            if ( plugin.getUseVersion() != null )
            {
                serializer.startTag( NAMESPACE, "useVersion" ).text( plugin.getUseVersion() ).endTag( NAMESPACE, "useVersion" );
            }
            if ( plugin.getRejectedVersions() != null && plugin.getRejectedVersions().size() > 0 )
            {
                serializer.startTag( NAMESPACE, "rejectedVersions" );
                for ( Iterator iter = plugin.getRejectedVersions().iterator(); iter.hasNext(); )
                {
                    String rejectedVersion = (String) iter.next();
                    serializer.startTag( NAMESPACE, "rejectedVersion" ).text( rejectedVersion ).endTag( NAMESPACE, "rejectedVersion" );
                }
                serializer.endTag( NAMESPACE, "rejectedVersions" );
            }
            serializer.endTag( NAMESPACE, tagName );
        }
    } //-- void writePlugin(Plugin, String, XmlSerializer) 

    /**
     * Method writePluginRegistry
     * 
     * @param pluginRegistry
     * @param serializer
     * @param tagName
     */
    private void writePluginRegistry(PluginRegistry pluginRegistry, String tagName, XmlSerializer serializer)
        throws java.io.IOException
    {
        if ( pluginRegistry != null )
        {
            serializer.startTag( NAMESPACE, tagName );
            if ( pluginRegistry.getUpdateInterval() != null && !pluginRegistry.getUpdateInterval().equals( "never" ) )
            {
                serializer.startTag( NAMESPACE, "updateInterval" ).text( pluginRegistry.getUpdateInterval() ).endTag( NAMESPACE, "updateInterval" );
            }
            if ( pluginRegistry.getAutoUpdate() != null )
            {
                serializer.startTag( NAMESPACE, "autoUpdate" ).text( pluginRegistry.getAutoUpdate() ).endTag( NAMESPACE, "autoUpdate" );
            }
            if ( pluginRegistry.getCheckLatest() != null )
            {
                serializer.startTag( NAMESPACE, "checkLatest" ).text( pluginRegistry.getCheckLatest() ).endTag( NAMESPACE, "checkLatest" );
            }
            if ( pluginRegistry.getPlugins() != null && pluginRegistry.getPlugins().size() > 0 )
            {
                serializer.startTag( NAMESPACE, "plugins" );
                for ( Iterator iter = pluginRegistry.getPlugins().iterator(); iter.hasNext(); )
                {
                    Plugin o = (Plugin) iter.next();
                    writePlugin( o, "plugin", serializer );
                }
                serializer.endTag( NAMESPACE, "plugins" );
            }
            serializer.endTag( NAMESPACE, tagName );
        }
    } //-- void writePluginRegistry(PluginRegistry, String, XmlSerializer) 

    /**
     * Method writeTrackableBase
     * 
     * @param trackableBase
     * @param serializer
     * @param tagName
     */
    private void writeTrackableBase(TrackableBase trackableBase, String tagName, XmlSerializer serializer)
        throws java.io.IOException
    {
        if ( trackableBase != null )
        {
            serializer.startTag( NAMESPACE, tagName );
            serializer.endTag( NAMESPACE, tagName );
        }
    } //-- void writeTrackableBase(TrackableBase, String, XmlSerializer) 

}
