/*
 * $Id$
 */

package org.apache.maven.usability.plugin;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.util.Date;

/**
 * The root of a parameter plugin expression document.
 * 
 * @version $Revision$ $Date$
 */
public class ExpressionDocumentation implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field expressions
     */
    private java.util.List expressions;


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addExpression
     * 
     * @param expression
     */
    public void addExpression(Expression expression)
    {
        if ( !(expression instanceof Expression) )
        {
            throw new ClassCastException( "ExpressionDocumentation.addExpressions(expression) parameter must be instanceof " + Expression.class.getName() );
        }
        getExpressions().add( expression );
    } //-- void addExpression(Expression) 

    /**
     * Method getExpressions
     */
    public java.util.List getExpressions()
    {
        if ( this.expressions == null )
        {
            this.expressions = new java.util.ArrayList();
        }
        
        return this.expressions;
    } //-- java.util.List getExpressions() 

    /**
     * Method removeExpression
     * 
     * @param expression
     */
    public void removeExpression(Expression expression)
    {
        if ( !(expression instanceof Expression) )
        {
            throw new ClassCastException( "ExpressionDocumentation.removeExpressions(expression) parameter must be instanceof " + Expression.class.getName() );
        }
        getExpressions().remove( expression );
    } //-- void removeExpression(Expression) 

    /**
     * Set The list of plugin parameter expressions described by
     * this
     *             document.
     * 
     * @param expressions
     */
    public void setExpressions(java.util.List expressions)
    {
        this.expressions = expressions;
    } //-- void setExpressions(java.util.List) 

    private java.util.Map expressionsBySyntax;
    
    public java.util.Map getExpressionsBySyntax()
    {
        if ( expressionsBySyntax == null )
        {
            expressionsBySyntax = new java.util.HashMap();
       
            java.util.List expressions = getExpressions();
       
            if ( expressions != null && !expressions.isEmpty() )
            {
                for ( java.util.Iterator it = expressions.iterator(); it.hasNext(); )
                {
                    Expression expr = (Expression) it.next();
       
                    expressionsBySyntax.put( expr.getSyntax(), expr );
                }
            }
        }
        
        return expressionsBySyntax;
    }
    
    public void flushExpressionsBySyntax()
    {
        expressionsBySyntax = null;
    }

    private String modelEncoding = "UTF-8";

    public void setModelEncoding( String modelEncoding )
    {
        this.modelEncoding = modelEncoding;
    }

    public String getModelEncoding()
    {
        return modelEncoding;
    }}
