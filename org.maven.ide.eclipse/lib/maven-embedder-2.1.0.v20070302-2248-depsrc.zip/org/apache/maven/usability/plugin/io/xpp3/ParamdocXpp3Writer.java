/*
 * $Id$
 */

package org.apache.maven.usability.plugin.io.xpp3;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.Writer;
import java.text.DateFormat;
import java.util.Iterator;
import java.util.Locale;
import org.apache.maven.usability.plugin.Expression;
import org.apache.maven.usability.plugin.ExpressionDocumentation;
import org.codehaus.plexus.util.xml.pull.MXSerializer;
import org.codehaus.plexus.util.xml.pull.XmlSerializer;

/**
 * Class ParamdocXpp3Writer.
 * 
 * @version $Revision$ $Date$
 */
public class ParamdocXpp3Writer {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field NAMESPACE
     */
    private String NAMESPACE;


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method write
     * 
     * @param writer
     * @param expressionDocumentation
     */
    public void write(Writer writer, ExpressionDocumentation expressionDocumentation)
        throws java.io.IOException
    {
        XmlSerializer serializer = new MXSerializer();
        serializer.setProperty( "http://xmlpull.org/v1/doc/properties.html#serializer-indentation", "  " );
        serializer.setProperty( "http://xmlpull.org/v1/doc/properties.html#serializer-line-separator", "\n" );
        serializer.setOutput( writer );
        serializer.startDocument( expressionDocumentation.getModelEncoding(), null );
        writeExpressionDocumentation( expressionDocumentation, "paramdoc", serializer );
        serializer.endDocument();
    } //-- void write(Writer, ExpressionDocumentation) 

    /**
     * Method writeExpression
     * 
     * @param expression
     * @param serializer
     * @param tagName
     */
    private void writeExpression(Expression expression, String tagName, XmlSerializer serializer)
        throws java.io.IOException
    {
        if ( expression != null )
        {
            serializer.startTag( NAMESPACE, tagName );
            if ( expression.getSyntax() != null )
            {
                serializer.startTag( NAMESPACE, "syntax" ).text( expression.getSyntax() ).endTag( NAMESPACE, "syntax" );
            }
            if ( expression.getDescription() != null )
            {
                serializer.startTag( NAMESPACE, "description" ).text( expression.getDescription() ).endTag( NAMESPACE, "description" );
            }
            if ( expression.getConfiguration() != null )
            {
                serializer.startTag( NAMESPACE, "configuration" ).text( expression.getConfiguration() ).endTag( NAMESPACE, "configuration" );
            }
            if ( expression.getCliOptions() != null && expression.getCliOptions().size() > 0 )
            {
                serializer.startTag( NAMESPACE, "cliOptions" );
                for ( Iterator iter = expression.getCliOptions().keySet().iterator(); iter.hasNext(); )
                {
                    String key = (String) iter.next();
                    String value = (String) expression.getCliOptions().get( key );
                    serializer.startTag( NAMESPACE, "cliOption" );
                    serializer.startTag( NAMESPACE, "key" ).text( key ).endTag( NAMESPACE, "key" );
                    serializer.startTag( NAMESPACE, "value" ).text( value ).endTag( NAMESPACE, "value" );
                    serializer.endTag( NAMESPACE, "cliOption" );
                }
                serializer.endTag( NAMESPACE, "cliOptions" );
            }
            if ( expression.getApiMethods() != null && expression.getApiMethods().size() > 0 )
            {
                serializer.startTag( NAMESPACE, "apiMethods" );
                for ( Iterator iter = expression.getApiMethods().keySet().iterator(); iter.hasNext(); )
                {
                    String key = (String) iter.next();
                    String value = (String) expression.getApiMethods().get( key );
                    serializer.startTag( NAMESPACE, "apiMethod" );
                    serializer.startTag( NAMESPACE, "key" ).text( key ).endTag( NAMESPACE, "key" );
                    serializer.startTag( NAMESPACE, "value" ).text( value ).endTag( NAMESPACE, "value" );
                    serializer.endTag( NAMESPACE, "apiMethod" );
                }
                serializer.endTag( NAMESPACE, "apiMethods" );
            }
            if ( expression.getDeprecation() != null )
            {
                serializer.startTag( NAMESPACE, "deprecation" ).text( expression.getDeprecation() ).endTag( NAMESPACE, "deprecation" );
            }
            if ( expression.getBan() != null )
            {
                serializer.startTag( NAMESPACE, "ban" ).text( expression.getBan() ).endTag( NAMESPACE, "ban" );
            }
            if ( expression.isEditable() != true )
            {
                serializer.startTag( NAMESPACE, "editable" ).text( String.valueOf( expression.isEditable() ) ).endTag( NAMESPACE, "editable" );
            }
            serializer.endTag( NAMESPACE, tagName );
        }
    } //-- void writeExpression(Expression, String, XmlSerializer) 

    /**
     * Method writeExpressionDocumentation
     * 
     * @param expressionDocumentation
     * @param serializer
     * @param tagName
     */
    private void writeExpressionDocumentation(ExpressionDocumentation expressionDocumentation, String tagName, XmlSerializer serializer)
        throws java.io.IOException
    {
        if ( expressionDocumentation != null )
        {
            serializer.startTag( NAMESPACE, tagName );
            if ( expressionDocumentation.getExpressions() != null && expressionDocumentation.getExpressions().size() > 0 )
            {
                serializer.startTag( NAMESPACE, "expressions" );
                for ( Iterator iter = expressionDocumentation.getExpressions().iterator(); iter.hasNext(); )
                {
                    Expression o = (Expression) iter.next();
                    writeExpression( o, "expression", serializer );
                }
                serializer.endTag( NAMESPACE, "expressions" );
            }
            serializer.endTag( NAMESPACE, tagName );
        }
    } //-- void writeExpressionDocumentation(ExpressionDocumentation, String, XmlSerializer) 

}
