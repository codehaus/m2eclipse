package org.apache.maven;

import org.apache.maven.wagon.events.TransferListener;

/**
 * @author Jason van Zyl
 * @version $Revision: 470397 $
 */
public interface MavenTransferListener
    extends TransferListener
{
}
