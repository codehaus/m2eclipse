/*
 * $Id$
 */

package org.apache.maven.lifecycle.model;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.util.Date;

/**
 * null
 * 
 * @version $Revision$ $Date$
 */
public class BuildBinding extends LifecycleBinding 
implements java.io.Serializable
{


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field validate
     */
    private Phase validate = new Phase();

    /**
     * Field initialize
     */
    private Phase initialize = new Phase();

    /**
     * Field generateSources
     */
    private Phase generateSources = new Phase();

    /**
     * Field processSources
     */
    private Phase processSources = new Phase();

    /**
     * Field generateResources
     */
    private Phase generateResources = new Phase();

    /**
     * Field processResources
     */
    private Phase processResources = new Phase();

    /**
     * Field compile
     */
    private Phase compile = new Phase();

    /**
     * Field processClasses
     */
    private Phase processClasses = new Phase();

    /**
     * Field generateTestSources
     */
    private Phase generateTestSources = new Phase();

    /**
     * Field processTestSources
     */
    private Phase processTestSources = new Phase();

    /**
     * Field generateTestResources
     */
    private Phase generateTestResources = new Phase();

    /**
     * Field processTestResources
     */
    private Phase processTestResources = new Phase();

    /**
     * Field testCompile
     */
    private Phase testCompile = new Phase();

    /**
     * Field processTestClasses
     */
    private Phase processTestClasses = new Phase();

    /**
     * Field test
     */
    private Phase test = new Phase();

    /**
     * Field preparePackage
     */
    private Phase preparePackage = new Phase();

    /**
     * Field createPackage
     */
    private Phase createPackage = new Phase();

    /**
     * Field preIntegrationTest
     */
    private Phase preIntegrationTest = new Phase();

    /**
     * Field integrationTest
     */
    private Phase integrationTest = new Phase();

    /**
     * Field postIntegrationTest
     */
    private Phase postIntegrationTest = new Phase();

    /**
     * Field verify
     */
    private Phase verify = new Phase();

    /**
     * Field install
     */
    private Phase install = new Phase();

    /**
     * Field deploy
     */
    private Phase deploy = new Phase();


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Get null
     */
    public Phase getCompile()
    {
        return this.compile;
    } //-- Phase getCompile() 

    /**
     * Get null
     */
    public Phase getCreatePackage()
    {
        return this.createPackage;
    } //-- Phase getCreatePackage() 

    /**
     * Get null
     */
    public Phase getDeploy()
    {
        return this.deploy;
    } //-- Phase getDeploy() 

    /**
     * Get null
     */
    public Phase getGenerateResources()
    {
        return this.generateResources;
    } //-- Phase getGenerateResources() 

    /**
     * Get null
     */
    public Phase getGenerateSources()
    {
        return this.generateSources;
    } //-- Phase getGenerateSources() 

    /**
     * Get null
     */
    public Phase getGenerateTestResources()
    {
        return this.generateTestResources;
    } //-- Phase getGenerateTestResources() 

    /**
     * Get null
     */
    public Phase getGenerateTestSources()
    {
        return this.generateTestSources;
    } //-- Phase getGenerateTestSources() 

    /**
     * Get null
     */
    public Phase getInitialize()
    {
        return this.initialize;
    } //-- Phase getInitialize() 

    /**
     * Get null
     */
    public Phase getInstall()
    {
        return this.install;
    } //-- Phase getInstall() 

    /**
     * Get null
     */
    public Phase getIntegrationTest()
    {
        return this.integrationTest;
    } //-- Phase getIntegrationTest() 

    /**
     * Get null
     */
    public Phase getPostIntegrationTest()
    {
        return this.postIntegrationTest;
    } //-- Phase getPostIntegrationTest() 

    /**
     * Get null
     */
    public Phase getPreIntegrationTest()
    {
        return this.preIntegrationTest;
    } //-- Phase getPreIntegrationTest() 

    /**
     * Get null
     */
    public Phase getPreparePackage()
    {
        return this.preparePackage;
    } //-- Phase getPreparePackage() 

    /**
     * Get null
     */
    public Phase getProcessClasses()
    {
        return this.processClasses;
    } //-- Phase getProcessClasses() 

    /**
     * Get null
     */
    public Phase getProcessResources()
    {
        return this.processResources;
    } //-- Phase getProcessResources() 

    /**
     * Get null
     */
    public Phase getProcessSources()
    {
        return this.processSources;
    } //-- Phase getProcessSources() 

    /**
     * Get null
     */
    public Phase getProcessTestClasses()
    {
        return this.processTestClasses;
    } //-- Phase getProcessTestClasses() 

    /**
     * Get null
     */
    public Phase getProcessTestResources()
    {
        return this.processTestResources;
    } //-- Phase getProcessTestResources() 

    /**
     * Get null
     */
    public Phase getProcessTestSources()
    {
        return this.processTestSources;
    } //-- Phase getProcessTestSources() 

    /**
     * Get null
     */
    public Phase getTest()
    {
        return this.test;
    } //-- Phase getTest() 

    /**
     * Get null
     */
    public Phase getTestCompile()
    {
        return this.testCompile;
    } //-- Phase getTestCompile() 

    /**
     * Get null
     */
    public Phase getValidate()
    {
        return this.validate;
    } //-- Phase getValidate() 

    /**
     * Get null
     */
    public Phase getVerify()
    {
        return this.verify;
    } //-- Phase getVerify() 

    /**
     * Set null
     * 
     * @param compile
     */
    public void setCompile(Phase compile)
    {
        this.compile = compile;
    } //-- void setCompile(Phase) 

    /**
     * Set null
     * 
     * @param createPackage
     */
    public void setCreatePackage(Phase createPackage)
    {
        this.createPackage = createPackage;
    } //-- void setCreatePackage(Phase) 

    /**
     * Set null
     * 
     * @param deploy
     */
    public void setDeploy(Phase deploy)
    {
        this.deploy = deploy;
    } //-- void setDeploy(Phase) 

    /**
     * Set null
     * 
     * @param generateResources
     */
    public void setGenerateResources(Phase generateResources)
    {
        this.generateResources = generateResources;
    } //-- void setGenerateResources(Phase) 

    /**
     * Set null
     * 
     * @param generateSources
     */
    public void setGenerateSources(Phase generateSources)
    {
        this.generateSources = generateSources;
    } //-- void setGenerateSources(Phase) 

    /**
     * Set null
     * 
     * @param generateTestResources
     */
    public void setGenerateTestResources(Phase generateTestResources)
    {
        this.generateTestResources = generateTestResources;
    } //-- void setGenerateTestResources(Phase) 

    /**
     * Set null
     * 
     * @param generateTestSources
     */
    public void setGenerateTestSources(Phase generateTestSources)
    {
        this.generateTestSources = generateTestSources;
    } //-- void setGenerateTestSources(Phase) 

    /**
     * Set null
     * 
     * @param initialize
     */
    public void setInitialize(Phase initialize)
    {
        this.initialize = initialize;
    } //-- void setInitialize(Phase) 

    /**
     * Set null
     * 
     * @param install
     */
    public void setInstall(Phase install)
    {
        this.install = install;
    } //-- void setInstall(Phase) 

    /**
     * Set null
     * 
     * @param integrationTest
     */
    public void setIntegrationTest(Phase integrationTest)
    {
        this.integrationTest = integrationTest;
    } //-- void setIntegrationTest(Phase) 

    /**
     * Set null
     * 
     * @param postIntegrationTest
     */
    public void setPostIntegrationTest(Phase postIntegrationTest)
    {
        this.postIntegrationTest = postIntegrationTest;
    } //-- void setPostIntegrationTest(Phase) 

    /**
     * Set null
     * 
     * @param preIntegrationTest
     */
    public void setPreIntegrationTest(Phase preIntegrationTest)
    {
        this.preIntegrationTest = preIntegrationTest;
    } //-- void setPreIntegrationTest(Phase) 

    /**
     * Set null
     * 
     * @param preparePackage
     */
    public void setPreparePackage(Phase preparePackage)
    {
        this.preparePackage = preparePackage;
    } //-- void setPreparePackage(Phase) 

    /**
     * Set null
     * 
     * @param processClasses
     */
    public void setProcessClasses(Phase processClasses)
    {
        this.processClasses = processClasses;
    } //-- void setProcessClasses(Phase) 

    /**
     * Set null
     * 
     * @param processResources
     */
    public void setProcessResources(Phase processResources)
    {
        this.processResources = processResources;
    } //-- void setProcessResources(Phase) 

    /**
     * Set null
     * 
     * @param processSources
     */
    public void setProcessSources(Phase processSources)
    {
        this.processSources = processSources;
    } //-- void setProcessSources(Phase) 

    /**
     * Set null
     * 
     * @param processTestClasses
     */
    public void setProcessTestClasses(Phase processTestClasses)
    {
        this.processTestClasses = processTestClasses;
    } //-- void setProcessTestClasses(Phase) 

    /**
     * Set null
     * 
     * @param processTestResources
     */
    public void setProcessTestResources(Phase processTestResources)
    {
        this.processTestResources = processTestResources;
    } //-- void setProcessTestResources(Phase) 

    /**
     * Set null
     * 
     * @param processTestSources
     */
    public void setProcessTestSources(Phase processTestSources)
    {
        this.processTestSources = processTestSources;
    } //-- void setProcessTestSources(Phase) 

    /**
     * Set null
     * 
     * @param test
     */
    public void setTest(Phase test)
    {
        this.test = test;
    } //-- void setTest(Phase) 

    /**
     * Set null
     * 
     * @param testCompile
     */
    public void setTestCompile(Phase testCompile)
    {
        this.testCompile = testCompile;
    } //-- void setTestCompile(Phase) 

    /**
     * Set null
     * 
     * @param validate
     */
    public void setValidate(Phase validate)
    {
        this.validate = validate;
    } //-- void setValidate(Phase) 

    /**
     * Set null
     * 
     * @param verify
     */
    public void setVerify(Phase verify)
    {
        this.verify = verify;
    } //-- void setVerify(Phase) 


    public String getId()
    {
        return "build";
    }
          
    public java.util.List getPhasesInOrder()
    {
        java.util.List phases = new java.util.ArrayList();
        
        phases.add( getValidate() );
        phases.add( getInitialize() );
        phases.add( getGenerateSources() );
        phases.add( getProcessSources() );
        phases.add( getGenerateResources() );
        phases.add( getProcessResources() );
        phases.add( getCompile() );
        phases.add( getProcessClasses() );
        phases.add( getGenerateTestSources() );
        phases.add( getProcessTestSources() );
        phases.add( getGenerateTestResources() );
        phases.add( getProcessTestResources() );
        phases.add( getTestCompile() );
        phases.add( getProcessTestClasses() );
        phases.add( getTest() );
        phases.add( getPreparePackage() );
        phases.add( getCreatePackage() );
        phases.add( getPreIntegrationTest() );
        phases.add( getIntegrationTest() );
        phases.add( getPostIntegrationTest() );
        phases.add( getVerify() );
        phases.add( getInstall() );
        phases.add( getDeploy() );
        
        return java.util.Collections.unmodifiableList( phases );
    }
    
    public java.util.List getPhaseNamesInOrder()
    {
        java.util.List phases = new java.util.ArrayList();
        
        phases.add( "validate" );
        phases.add( "initialize" );
        phases.add( "generate-sources" );
        phases.add( "process-sources" );
        phases.add( "generate-resources" );
        phases.add( "process-resources" );
        phases.add( "compile" );
        phases.add( "process-classes" );
        phases.add( "generate-test-sources" );
        phases.add( "process-test-sources" );
        phases.add( "generate-test-resources" );
        phases.add( "process-test-resources" );
        phases.add( "test-compile" );
        phases.add( "process-test-classes" );
        phases.add( "test" );
        phases.add( "prepare-package" );
        phases.add( "package" );
        phases.add( "pre-integration-test" );
        phases.add( "integration-test" );
        phases.add( "post-integration-test" );
        phases.add( "verify" );
        phases.add( "install" );
        phases.add( "deploy" );
        
        return java.util.Collections.unmodifiableList( phases );
    }
          
    private String modelEncoding = "UTF-8";

    public void setModelEncoding( String modelEncoding )
    {
        this.modelEncoding = modelEncoding;
    }

    public String getModelEncoding()
    {
        return modelEncoding;
    }
}
